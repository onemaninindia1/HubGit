Instructions:
1. Download the zip file and unzip to your convenient location.
2. Open the command prompt and point the location where you unzip the POC files.
3. Type npm install in command prompt. you will see all necessary nodemodules are downloading 
4. Type node server.js in command prompt 
5. open the browser and type http://localhost:8080/

Pre-requisites:
1. Node Package
2. Internet Connection