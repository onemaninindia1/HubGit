var express = require('express'),
    app     = express(),
    eps     = require('ejs'),
	bodyParser = require('body-parser'),
    morgan  = require('morgan');

    var MsTranslator = require('./mstranslator');


var client_secret='9xtw2KehI2lz/YPrDZuSiUBjz6j4g8qTjgBOcEyeepo=';
var client_id='123Trans_456';

if (!client_secret || !client_id) {
  console.log('client_secret and client_id missing');
  process.exit(1);
}




var client = new MsTranslator({
  client_id: client_id,
  client_secret: client_secret
});

app.engine('html', require('ejs').renderFile);
app.use(morgan('combined'))
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

var port = process.env.PORT || 8080,
    ip   = process.env.IP   || '0.0.0.0';

app.get('/', function (req, res) {
    res.render('index.html');

});


app.post('/search', function (req, res) {
    
var idea = req.body.idea;
var ideacontent = req.body.ideacontent;
var fromlang = req.body.fromlang;
var tolang = req.body.tolang;

var params = {
  text: ideacontent,
  from: fromlang,
  to: tolang
};

console.log(params);

client.initialize_token(function(){
  client.translate(params, function(err, data) {
    if (err) console.log('error:' + err.message);
 
   
   res.json({ success: data});res.end();
        return false;
  
  });
	
	
	
	
});

});

// error handling
app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500).send('Something bad happened!');
});

app.listen(port, ip);
console.log('Server running on http://%s:%s', ip, port);

module.exports = app ;
